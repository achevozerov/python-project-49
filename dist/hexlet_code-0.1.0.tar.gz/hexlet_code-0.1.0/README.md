### Hexlet tests and linter status:
[![Actions Status](https://github.com/achevozerov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/achevozerov/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/8fe050c33784d0717b80/maintainability)](https://codeclimate.com/github/achevozerov/python-project-49/maintainability)

### Brain-even
[![asciicast](https://asciinema.org/a/tJIfYdGARGOHg18C7YpDW4KDX.svg)](https://asciinema.org/a/tJIfYdGARGOHg18C7YpDW4KDX)

### Brain-calc
[![asciicast](https://asciinema.org/a/D0acj2HsMDFW1Lx2ebvb4Bek5.svg)](https://asciinema.org/a/D0acj2HsMDFW1Lx2ebvb4Bek5)

### Brain-gcd
[![asciicast](https://asciinema.org/a/Q5JDNYLmKc8jjEkNZy4tXX85s.svg)](https://asciinema.org/a/Q5JDNYLmKc8jjEkNZy4tXX85s)

### Brain-progression

[![asciicast](https://asciinema.org/a/GbmjALf3xUYf9gTT4ECTEhctj.svg)](https://asciinema.org/a/GbmjALf3xUYf9gTT4ECTEhctj)
