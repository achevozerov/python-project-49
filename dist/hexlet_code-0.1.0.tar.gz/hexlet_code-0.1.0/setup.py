# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/achevozerov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/achevozerov/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/8fe050c33784d0717b80/maintainability)](https://codeclimate.com/github/achevozerov/python-project-49/maintainability)\n\n### Brain-even\n[![asciicast](https://asciinema.org/a/tJIfYdGARGOHg18C7YpDW4KDX.svg)](https://asciinema.org/a/tJIfYdGARGOHg18C7YpDW4KDX)\n\n### Brain-calc\n[![asciicast](https://asciinema.org/a/D0acj2HsMDFW1Lx2ebvb4Bek5.svg)](https://asciinema.org/a/D0acj2HsMDFW1Lx2ebvb4Bek5)\n\n### Brain-gcd\n[![asciicast](https://asciinema.org/a/Q5JDNYLmKc8jjEkNZy4tXX85s.svg)](https://asciinema.org/a/Q5JDNYLmKc8jjEkNZy4tXX85s)\n\n### Brain-progression\n\n[![asciicast](https://asciinema.org/a/GbmjALf3xUYf9gTT4ECTEhctj.svg)](https://asciinema.org/a/GbmjALf3xUYf9gTT4ECTEhctj)\n\n### Brain-prime\n\n[![asciicast](https://asciinema.org/a/HVIsF62fZ6XI4v33O1sFzatic.svg)](https://asciinema.org/a/HVIsF62fZ6XI4v33O1sFzatic)\n',
    'author': 'Andrey Chevozerov',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
